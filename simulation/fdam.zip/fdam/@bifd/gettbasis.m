function tbasisobj = gettbasis(bifd)
tbasisobj = bifd.tbasisobj;